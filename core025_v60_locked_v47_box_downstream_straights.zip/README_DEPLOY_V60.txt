CORE025 v60 LOCKED V47 BASELINE BOX + DOWNSTREAM STRAIGHTS

Upload these to GitHub repo root:
- app.py
- requirements.txt

Streamlit main file path:
app.py

Daily workflow:
1. Upload FULL HISTORY.
2. Upload optional LAST 24 HOURS if needed.
3. Upload FULL TRUTH intelligence file.
4. Upload promoted separator library CSV.
5. Run Daily Prediction.
6. Run Straight Plays.

Locked rule:
- The v47/v45-era box/member layer is the baseline.
- Straight logic is downstream only.
- Straight logic never changes PredictedMember, Top2_pred, ThirdMember, PlayType, or RecommendedPlay.
- Recommended straights default to 2 per stream, matching the uploaded v47 straight report behavior.
