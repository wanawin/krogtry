Upload app.py, requirements.txt, and the data folder to the repo root. Set Streamlit main file path to app.py.
